Please include the following:
- description of the issue and steps to reproduce
- jsfiddle that reproduces your issue in its simplest form possible [required]


no jsfiddle == your issue will be closed
